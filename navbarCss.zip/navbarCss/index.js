let Menu = document.querySelector("#MenuBtn");
let Navbar = document.querySelector(".Navbar");

Menu.addEventListener("click", () => {
  Menu.classList.toggle("fa-times");
  Navbar.classList.toggle("active");
});
